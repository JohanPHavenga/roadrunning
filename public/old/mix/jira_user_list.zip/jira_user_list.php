<?php

$arrContextOptions = array(
    "ssl" => array(
        "verify_peer" => false,
        "verify_peer_name" => false,
    ),
);

$response = file_get_contents("https://jira.mixtelematics.com/rest/api/latest/user/search?startAt=0&maxResults=1000&username=.'", false, stream_context_create($arrContextOptions));
$response_array = json_decode($response);

echo "<p>There are <b>".count($response_array)."</b> users.</p>";
foreach ($response_array as $entry) {
    $name_array[] = $entry->displayName;
    echo $entry->displayName . "<br>";
}


die;

?>